# Coursework 1 Data Files

`words.txt` contains the words used by Wordle, in order of use, starting
with Game 0 (19 June 2021).  This includes words yet to appear in the game,
so don't examine this file too closely if you don't want any spoilers!

`test.txt` is a smaller file, used for unit testing.

**IMPORTANT: Do not remove, rename or alter these files!**
