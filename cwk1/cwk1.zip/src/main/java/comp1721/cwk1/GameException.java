// Exception class for use in COMP1721 Coursework 1

package comp1721.cwk1;

public class GameException extends RuntimeException {
  public GameException(String message) {
    super(message);
  }
}
